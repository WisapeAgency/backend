<?php
$this->pageCaption='About';
$this->pageTitle=Yii::app()->name . ' - ' . $this->pageCaption;
$this->pageDescription="Here's what this site is all about";
$this->breadcrumbs=array(
	'About',
);
?>
<p>This is a "static" page. You may change the content of this page
by updating the file <tt><?php echo __FILE__; ?></tt>.</p>
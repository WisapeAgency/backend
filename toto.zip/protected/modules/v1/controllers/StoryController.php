<?php

class StoryController extends ApiController{

    public function actionCreatezip(){
        $zip = Yii::app()->zip;
        $zip->makeZip('./','./toto.zip'); // make an ZIP archive
        var_export($zip->infosZip('./toto.zip'), false); // get infos of this ZIP archive (without files content)
        var_export($zip->infosZip('./toto.zip')); // get infos of this ZIP archive (with files content)
//        $zip->extractZip('./toto.zip', './1/'); //
    }

}
<?php
//两分钟内请求有效
define('TOKEN_EXPIRES',60*2);
define('KEY','FF0B6705E0F51022275BFEA19504BDF4');
define('WIS_USER',1);
define('FACE_BOOK_USER',2);
define('TWITTER_USER',3);
define('LIFE_TIME',3600);